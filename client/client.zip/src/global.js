let environment;

environment = {
    apiUrl: 'http://localhost:5000/v1'
}

export default environment;